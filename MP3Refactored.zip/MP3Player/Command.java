/**
 * This is a Command interface for the MP3 Player
 * @author Isabella Sturm
 * @version 23 Feburary 2017
 */
 public interface Command
 {
     public void execute();
 }