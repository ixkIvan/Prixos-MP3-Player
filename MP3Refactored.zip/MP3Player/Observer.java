
public interface Observer {

	public void update(int duration, String fileName, String title, String artist, String album, String genre);

	
			
}
